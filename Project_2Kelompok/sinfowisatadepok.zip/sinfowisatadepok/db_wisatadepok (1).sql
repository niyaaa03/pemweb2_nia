-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 06 Jul 2022 pada 14.07
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_wisatadepok`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `gallery_wisata`
--

CREATE TABLE `gallery_wisata` (
  `id` int(11) NOT NULL,
  `foto_wisata` varchar(255) DEFAULT NULL,
  `wisata_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `gallery_wisata`
--

INSERT INTO `gallery_wisata` (`id`, `foto_wisata`, `wisata_id`) VALUES
(56, 'ffcd3f95df27d005179eb33cd17a766d.jpg', 18),
(60, 'a5754cc2ec76c80a27dd4afcb8019f4d.jpg', 21),
(61, '3afc51b41984f7f2fcde941c43d13173.jpg', 20),
(65, 'bcae56077baaf05a93e3abdb47fb9fbd.jpg', 13),
(68, '90871b425cfaca6b7b4d1bfca22e91a4.jpg', 5),
(69, '4ab10b02ec27a1c19867828d3b037d18.jpg', 7),
(70, 'dfa5799ddf5d21f8402125e76993086f.jpg', 2),
(71, '27968d85be43ccc3c2e8a94d6c4ee982.jpg', 8),
(72, '6abec2bfb7c9c1e7c3a6a4dc7ee1bcb6.jpeg', 9),
(73, 'be79ef7b9441c4f4b98c0727c9ad5bfc.jpg', 3),
(74, '684c7f55c3b7fa01c3c883f20fd07e4e.jpg', 11),
(75, '9cfd9b48f204e1e3cf82191419ef0e68.jpg', 10),
(76, 'c50a161b1898215556ccb51280ca0512.jpg', 6),
(77, '0fffe4ba8b4f28571a7cdc8480d5449d.jpg', 4),
(78, '858785a77c164606654a3210011aeebc.jpg', 1),
(79, '29d77c6a6ebc7a79e59ce43c9a3e6465.JPG', 22),
(80, '50dfc4ae2ba619c2178f522b0a0c42e2.jpg', 17),
(81, 'f9d217ab9b1a91e98cff339058497806.jpg', 14),
(82, 'fe85cd6b59361dc2040c0ea5dc9bf0df.jpg', 19),
(83, '959b690e413f847d776c1a17f7edf6c8.jpg', 16),
(84, 'd92354f7287f3def6009218a3b4a4941.jpg', 15),
(85, 'a623fb054c306d227450f80814e3afd7.jpg', 31),
(86, '3bafbf4b828e2691262285d845f1ef30.jpg', 12);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_kuliner`
--

CREATE TABLE `jenis_kuliner` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `jenis_kuliner`
--

INSERT INTO `jenis_kuliner` (`id`, `nama`) VALUES
(1, 'Cafe'),
(2, 'Restaurant');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_wisata`
--

CREATE TABLE `jenis_wisata` (
  `id` int(11) NOT NULL,
  `nama` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `jenis_wisata`
--

INSERT INTO `jenis_wisata` (`id`, `nama`) VALUES
(1, 'Argo Wisata'),
(2, 'Taman Wisata'),
(3, 'Wisata Religius'),
(5, 'Water Park');

-- --------------------------------------------------------

--
-- Struktur dari tabel `profesi`
--

CREATE TABLE `profesi` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `profesi`
--

INSERT INTO `profesi` (`id`, `nama`) VALUES
(1, 'Guru'),
(2, 'Mahasiswa'),
(3, 'Wiraswasta'),
(4, 'Pegawai Swasta'),
(5, 'Umum'),
(7, 'Software Development');

-- --------------------------------------------------------

--
-- Struktur dari tabel `testimoni`
--

CREATE TABLE `testimoni` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `wisata_id` int(11) NOT NULL,
  `profesi_id` int(11) NOT NULL,
  `rating` smallint(6) DEFAULT NULL,
  `komentar` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `testimoni`
--

INSERT INTO `testimoni` (`id`, `nama`, `email`, `wisata_id`, `profesi_id`, `rating`, `komentar`, `user_id`, `created_at`, `foto`) VALUES
(3, 'Nabila Fajri Syifa Dewi', 'admin@gmail.com', 15, 3, 2, 'Tempatnnya bikin nyaman, asyik dan estetik. Mantulll masyaallah Sangat rekomendasi', 2, '2022-06-07 21:58:57', '16d33eef41b9d5a32459e322ae83d1ab.png'),
(4, 'Nia Anggraeni', 'member@gmail.com', 9, 3, 3, 'Tempat Wisata di daerah ini cukup terkenal, banyak wisatawan dari luar kota. Seperti Bogor, Depok, Jakarta, dan Tangerang.', 13, '2022-03-05 18:58:57', '16d33eef41b9d5a32459e322ae83d1ab.png'),
(5, 'Siti Rohmah', 'member@gmail.com', 6, 5, 5, 'Kolom renang anak, tempatnya nyaman dan bayar nya murah', 12, '2022-05-10 14:56:28', NULL),
(6, 'Syavira Aulia Syamsi', 'member@gmail.com', 10, 4, 1, 'Sejuk dan fasilitas bisa digunakan untuk umum, muantep poll', 14, '2022-04-18 19:20:10', NULL),
(7, 'Alfi', 'alfi01@gmail.com', 1, 7, 1, 'islamic, tempatnnya nyaman dan sejuk, cocok untuk beribadah ', NULL, '2022-05-05 01:40:50', NULL),
(8, 'Syahrul', 'syahrul03@gmail.com', 16, 1, 1, 'makanannya enakkk poll murah murah muanteppp', NULL, '2022-06-01 11:30:59', NULL),
(9, 'Bia', 'bia@gmail.com', 7, 2, 5, 'puas dengan tempatnya, cocok untuk healing', NULL, '2022-02-11 17:03:57', NULL),
(10, 'Tulus', 'tulus@gmail.com', 13, 5, 3, 'cafe termurah dan wenak poll', NULL, '2022-04-18 17:28:57', NULL),
(11, 'aulia', 'aulia@gmail.com', 1, 2, 3, 'tempatnya nyaman okky bngtt', NULL, '2021-01-05 21:58:57', NULL),
(12, 'Alfi', 'alfi@gmail.com', 7, 7, 5, 'nyaman bngt tempatnnyaaa', NULL, '2022-07-05 21:58:57', NULL),
(13, 'Nayda ', 'nadya20@gmail.com', 2, 5, 5, 'Bisa kasih makan hewan anak-anak jadi suka dan belajar memberi', NULL, '2022-07-06 11:07:17', NULL),
(14, 'bayu', 'bayu10@gmail.com', 5, 1, 4, 'Tempat yang cocok buat liburan', NULL, '2022-03-03 13:18:07', NULL),
(15, 'Maria', 'maria16@gmail.com', 3, 3, 3, 'objek yang ditawarkan lumayan', NULL, '2022-01-08 15:08:57', NULL),
(16, 'Syavira Aulia Syamsi', 'vira12@gmail.com', 15, 2, 4, 'nyaman tempatnnya', NULL, '2022-11-05 21:58:57', NULL),
(17, 'Nia Anggraeni', 'nia10@gmail.com', 18, 5, 3, 'top poll', NULL, '2022-08-05 21:58:57', NULL),
(18, 'Siti Rohmah', 'rohmah15@gmail.com', 12, 3, 4, 'tempatnnya bagus buat anak tongkrongan', NULL, '2022-07-05 21:58:57', NULL),
(20, 'anggraeni', 'anggraeni@gmail.com', 3, 1, 4, 'keren abiss', NULL, '2022-08-02 17:50:57', NULL),
(21, 'dilah ', 'dila@gmail.com', 21, 4, 3, 'kopi nya enakkk', NULL, '2022-07-05 21:58:57', NULL),
(22, 'lukman', 'lukman@gmail.com', 4, 1, 2, 'tamannya baguss', NULL, '2022-01-05 11:15:57', NULL),
(23, 'mai', 'mai02@gmail.com', 19, 5, 1, 'baguss cafe nya', NULL, '2022-03-01 14:18:57', NULL),
(24, 'seto', 'seto@gmail.com', 14, 4, 5, 'bagusss bngettt', NULL, '2022-02-05 19:58:57', NULL),
(27, 'Syavira Aulia Syamsi', 'vira10@gmail.com', 1, 2, 2, 'okey bangettt', NULL, '2022-02-02 18:18:17', NULL),
(28, 'Linda ', 'linda@gmail.com', 20, 2, 1, 'Rekomendasi kopi', NULL, '2022-06-05 17:16:40', NULL),
(30, 'irull', 'irul03@gmail.com', 5, 2, 2, 'airnnya jernihh', NULL, '2022-05-05 19:19:17', NULL),
(31, 'Rama', 'rama11@gmail.com', 2, 4, 4, 'baguss tempatnnya ', NULL, '2022-02-03 10:58:57', NULL),
(32, 'Lana Faith', 'Praesent.luctus.Curabitur@et.com', 13, 2, 2, 'Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit. Cras lorem', NULL, '2021-07-05 21:58:57', NULL),
(33, 'Francesca Abel', 'imperdiet.ullamcorper@elementumduiquis.org', 17, 2, 4, 'sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec est mauris, rhoncus id, mollis nec, cursus a, enim.', NULL, '2021-07-05 21:58:57', NULL),
(34, 'Fleur Melvin', 'amet@vulputate.co.uk', 20, 1, 3, 'primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec tincidunt. Donec vitae erat vel pede blandit congue. In scelerisque scelerisque', NULL, '2021-07-05 21:58:57', NULL),
(35, 'Maile Cecilia', 'libero.Proin@Nullaaliquet.edu', 22, 3, 3, 'eget magna. Suspendisse tristique neque venenatis lacus. Etiam bibendum fermentum metus. Aenean sed pede nec ante blandit viverra. Donec tempus, lorem fringilla', NULL, '2021-07-05 21:58:57', NULL),
(36, 'Isaac Serena', 'at.lacus@auctor.org', 12, 3, 2, 'turpis. Aliquam adipiscing lobortis risus. In mi pede, nonummy ut, molestie in, tempus eu, ligula. Aenean euismod mauris eu elit. Nulla facilisi.', NULL, '2021-07-05 21:58:57', NULL),
(37, 'Logan Lareina', 'Aenean.euismod@lobortisnisi.net', 8, 4, 3, 'malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam', NULL, '2021-07-05 21:58:57', NULL),
(38, 'Dante Yen', 'ornare.In@Craseget.edu', 13, 4, 1, 'tempor bibendum. Donec felis orci, adipiscing non, luctus sit amet, faucibus ut, nulla. Cras eu tellus eu augue porttitor interdum. Sed auctor', NULL, '2021-07-05 21:58:57', NULL),
(39, 'Rigel Regan', 'semper.tellus.id@dolorquamelementum.com', 17, 2, 1, 'aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est. Nunc laoreet lectus quis massa. Mauris vestibulum,', NULL, '2021-07-05 21:58:57', NULL),
(40, 'Abraham Latifah', 'velit@enimnectempus.ca', 12, 3, 3, 'ultrices posuere cubilia Curae; Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis', NULL, '2021-07-05 21:58:57', NULL),
(41, 'Shad Nola', 'ultricies.ligula.Nullam@erat.co.uk', 20, 1, 5, 'molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec, eleifend non,', NULL, '2021-07-05 21:58:57', NULL),
(42, 'Craig Noelani', 'in@dapibus.org', 10, 3, 4, 'nulla. Cras eu tellus eu augue porttitor interdum. Sed auctor odio a purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis', NULL, '2021-07-05 21:58:57', NULL),
(43, 'Rhoda Burke', 'egestas.Duis.ac@Nullamnisl.co.uk', 4, 1, 1, 'sed, hendrerit a, arcu. Sed et libero. Proin mi. Aliquam gravida mauris ut mi. Duis risus odio, auctor vitae, aliquet nec, imperdiet', NULL, '2021-07-05 21:58:57', NULL),
(44, 'Stone Barbara', 'quis@consectetuerrhoncusNullam.edu', 21, 5, 1, 'amet nulla. Donec non justo. Proin non massa non ante bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus urna convallis erat,', NULL, '2021-07-05 21:58:57', NULL),
(45, 'Hilary Chaim', 'amet.diam@perinceptoshymenaeos.net', 19, 1, 4, 'sem ut dolor dapibus gravida. Aliquam tincidunt, nunc ac mattis ornare, lectus ante dictum mi, ac mattis velit justo nec ante. Maecenas', NULL, '2021-07-05 21:58:57', NULL),
(46, 'Peter Dacey', 'primis.in@sed.net', 13, 3, 1, 'metus sit amet ante. Vivamus non lorem vitae odio sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec', NULL, '2021-07-05 21:58:57', NULL),
(47, 'Kylee Eliana', 'laoreet@enimgravida.co.uk', 21, 4, 5, 'Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla. Integer urna. Vivamus molestie', NULL, '2021-07-05 21:58:57', NULL),
(48, 'Yoko Ciaran', 'sed.pede@Crasloremlorem.ca', 21, 1, 5, 'blandit enim consequat purus. Maecenas libero est, congue a, aliquet vel, vulputate eu, odio. Phasellus at augue id ante dictum cursus. Nunc', NULL, '2021-07-05 21:58:57', NULL),
(49, 'Nissim Raja', 'nisi@sit.org', 6, 2, 5, 'Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Phasellus ornare. Fusce mollis. Duis sit amet diam eu', NULL, '2021-07-05 21:58:57', NULL),
(50, 'Hayes Katell', 'auctor.ullamcorper.nisl@pharetrasedhendrerit.ca', 19, 3, 2, 'neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet', NULL, '2021-07-05 21:58:57', NULL),
(51, 'Castor Jakeem', 'mattis@varius.org', 10, 4, 4, 'Phasellus ornare. Fusce mollis. Duis sit amet diam eu dolor egestas rhoncus. Proin nisl sem, consequat nec, mollis vitae, posuere at, velit.', NULL, '2021-07-05 21:58:57', NULL),
(52, 'Kiayada Martena', 'mus@liberoIntegerin.net', 19, 2, 5, 'id sapien. Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis', NULL, '2021-07-05 21:58:57', NULL),
(53, 'Keely Wyatt', 'Phasellus@eunibhvulputate.ca', 12, 2, 5, 'odio. Etiam ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Etiam laoreet, libero', NULL, '2021-07-05 21:58:57', NULL),
(54, 'Phillip Sasha', 'in@necante.org', 12, 4, 4, 'Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer id magna et ipsum cursus vestibulum. Mauris', NULL, '2021-07-05 21:58:57', NULL),
(55, 'Kelly Nathaniel', 'libero.est@sodaleselit.net', 5, 4, 2, 'Curabitur sed tortor. Integer aliquam adipiscing lacus. Ut nec urna et arcu imperdiet ullamcorper. Duis at lacus. Quisque purus sapien, gravida non,', NULL, '2021-07-05 21:58:57', NULL),
(56, 'Wynne Eleanor', 'inceptos.hymenaeos@orci.co.uk', 15, 1, 2, 'Etiam gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat. Cras dictum ultricies ligula. Nullam enim. Sed nulla ante, iaculis nec,', NULL, '2021-07-05 21:58:57', NULL),
(57, 'Claire Brittany', 'pharetra.sed.hendrerit@ullamcorpermagnaSed.co.uk', 8, 2, 2, 'a, dui. Cras pellentesque. Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper magna. Sed eu eros. Nam consequat dolor vitae dolor. Donec', NULL, '2021-07-05 21:58:57', NULL),
(58, 'Lars Zena', 'mauris.Integer.sem@magnamalesuadavel.edu', 19, 5, 4, 'Vivamus nibh dolor, nonummy ac, feugiat non, lobortis quis, pede. Suspendisse dui. Fusce diam nunc, ullamcorper eu, euismod ac, fermentum vel, mauris.', NULL, '2021-07-05 21:58:57', NULL),
(59, 'Justin Jordan', 'sit.amet@iaculis.ca', 14, 4, 5, 'cursus et, eros. Proin ultrices. Duis volutpat nunc sit amet metus. Aliquam erat volutpat. Nulla facilisis. Suspendisse commodo tincidunt nibh. Phasellus nulla.', NULL, '2021-07-05 21:58:57', NULL),
(60, 'Briar Brian', 'fermentum.risus.at@placerategetvenenatis.ca', 1, 5, 4, 'enim, gravida sit amet, dapibus id, blandit at, nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin', NULL, '2021-07-05 21:58:57', NULL),
(61, 'Jasper Serina', 'purus.in.molestie@ultricies.org', 12, 3, 3, 'auctor velit. Aliquam nisl. Nulla eu neque pellentesque massa lobortis ultrices. Vivamus rhoncus. Donec est. Nunc ullamcorper, velit in aliquet lobortis, nisi', NULL, '2021-07-05 21:58:57', NULL),
(62, 'Judith Jamal', 'Suspendisse.tristique@pedeCras.edu', 8, 5, 2, 'semper pretium neque. Morbi quis urna. Nunc quis arcu vel quam dignissim pharetra. Nam ac nulla. In tincidunt congue turpis. In condimentum.', NULL, '2021-07-05 21:58:57', NULL),
(63, 'Callum Talon', 'sem@orcilobortis.ca', 6, 3, 3, 'ut aliquam iaculis, lacus pede sagittis augue, eu tempor erat neque non quam. Pellentesque habitant morbi tristique senectus et netus et malesuada', NULL, '2021-07-05 21:58:57', NULL),
(64, 'Rose Samuel', 'ac@dictumeu.org', 18, 4, 2, 'eu elit. Nulla facilisi. Sed neque. Sed eget lacus. Mauris non dui nec urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum ante', NULL, '2021-07-05 21:58:57', NULL),
(65, 'Olympia Orlando', 'augue.scelerisque@maurissitamet.edu', 11, 3, 5, 'Praesent luctus. Curabitur egestas nunc sed libero. Proin sed turpis nec mauris blandit mattis. Cras eget nisi dictum augue malesuada malesuada. Integer', NULL, '2021-07-05 21:58:57', NULL),
(66, 'Oscar Dorothy', 'Nullam.vitae.diam@In.net', 12, 4, 2, 'elit sed consequat auctor, nunc nulla vulputate dui, nec tempus mauris erat eget ipsum. Suspendisse sagittis. Nullam vitae diam. Proin dolor. Nulla', NULL, '2021-07-05 21:58:57', NULL),
(67, 'Illiana Chaney', 'ac.mattis.ornare@amalesuadaid.co.uk', 12, 4, 3, 'Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a, facilisis non, bibendum sed, est.', NULL, '2021-07-05 21:58:57', NULL),
(69, 'Nyssa Kamal', 'non.sapien.molestie@justonec.org', 19, 3, 4, 'enim. Etiam imperdiet dictum magna. Ut tincidunt orci quis lectus. Nullam suscipit, est ac facilisis facilisis, magna tellus faucibus leo, in lobortis', NULL, '2021-07-05 21:58:57', NULL),
(70, 'Merritt Elijah', 'et@ultricesposuere.co.uk', 19, 2, 2, 'Aliquam erat volutpat. Nulla facilisis. Suspendisse commodo tincidunt nibh. Phasellus nulla. Integer vulputate, risus a ultricies adipiscing, enim mi tempor lorem, eget', NULL, '2021-07-05 21:58:57', NULL),
(71, 'Vance Boris', 'vestibulum@Donec.edu', 2, 4, 4, 'In faucibus. Morbi vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac arcu. Nunc mauris. Morbi non sapien molestie orci tincidunt adipiscing.', NULL, '2021-07-05 21:58:57', NULL),
(72, 'Ocean Perry', 'ultrices.sit@pellentesquetellussem.net', 11, 2, 5, 'amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer aliquam adipiscing lacus. Ut nec urna et arcu imperdiet ullamcorper. Duis at lacus. Quisque', NULL, '2021-07-05 21:58:57', NULL),
(73, 'Fuller Austin', 'eu@Phasellus.ca', 2, 1, 5, 'dis parturient montes, nascetur ridiculus mus. Proin vel nisl. Quisque fringilla euismod enim. Etiam gravida molestie arcu. Sed eu nibh vulputate mauris', NULL, '2021-07-05 21:58:57', NULL),
(74, 'Natalie Bernard', 'Fusce.aliquam.enim@nuncnullavulputate.ca', 9, 1, 2, 'purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis est, vitae sodales nisi magna sed dui. Fusce aliquam, enim nec tempus', NULL, '2021-07-05 21:58:57', NULL),
(75, 'Vivien Sophia', 'Suspendisse.sed@ipsum.ca', 18, 2, 5, 'nec, cursus a, enim. Suspendisse aliquet, sem ut cursus luctus, ipsum leo elementum sem, vitae aliquam eros turpis non enim. Mauris quis', NULL, '2021-07-05 21:58:57', NULL),
(76, 'Irene Jordan', 'fames@quisturpis.net', 1, 3, 1, 'malesuada augue ut lacus. Nulla tincidunt, neque vitae semper egestas, urna justo faucibus lectus, a sollicitudin orci sem eget massa. Suspendisse eleifend.', NULL, '2021-07-05 21:58:57', NULL),
(77, 'Salvador Quentin', 'bibendum.fermentum.metus@ultriciessem.com', 4, 2, 3, 'Fusce aliquet magna a neque. Nullam ut nisi a odio semper cursus. Integer mollis. Integer tincidunt aliquam arcu. Aliquam ultrices iaculis odio.', NULL, '2021-07-05 21:58:57', NULL),
(78, 'Lyle Mia', 'montes@idrisus.com', 3, 2, 5, 'et netus et malesuada fames ac turpis egestas. Aliquam fringilla cursus purus. Nullam scelerisque neque sed sem egestas blandit. Nam nulla magna,', NULL, '2021-07-05 21:58:57', NULL),
(79, 'Miranda Sarah', 'mauris.ut@nuncnullavulputate.net', 2, 3, 3, 'velit eu sem. Pellentesque ut ipsum ac mi eleifend egestas. Sed pharetra, felis eget varius ultrices, mauris ipsum porta elit, a feugiat', NULL, '2021-07-05 21:58:57', NULL),
(80, 'Virginia Victor', 'aliquet.vel.vulputate@Vivamusnibh.edu', 10, 1, 2, 'a felis ullamcorper viverra. Maecenas iaculis aliquet diam. Sed diam lorem, auctor quis, tristique ac, eleifend vitae, erat. Vivamus nisi. Mauris nulla.', NULL, '2021-07-05 21:58:57', NULL),
(81, 'Shaine Jael', 'amet.risus@magnisdisparturient.co.uk', 5, 4, 4, 'tempus scelerisque, lorem ipsum sodales purus, in molestie tortor nibh sit amet orci. Ut sagittis lobortis mauris. Suspendisse aliquet molestie tellus. Aenean', NULL, '2021-07-05 21:58:57', NULL),
(82, 'Tanisha Kyla', 'tristique.ac@senectusetnetus.ca', 11, 1, 5, 'sollicitudin orci sem eget massa. Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero. Integer in magna. Phasellus dolor elit, pellentesque a,', NULL, '2021-07-05 21:58:57', NULL),
(83, 'Hector Harriet', 'risus.varius.orci@AliquamnislNulla.co.uk', 6, 5, 5, 'sit amet ante. Vivamus non lorem vitae odio sagittis semper. Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh. Donec est', NULL, '2021-07-05 21:58:57', NULL),
(84, 'Irene Kaseem', 'elit.Aliquam@uteros.com', 19, 4, 1, 'Curabitur consequat, lectus sit amet luctus vulputate, nisi sem semper erat, in consectetuer ipsum nunc id enim. Curabitur massa. Vestibulum accumsan neque', NULL, '2021-07-05 21:58:57', NULL),
(85, 'James Gil', 'arcu.imperdiet.ullamcorper@amagna.net', 22, 5, 3, 'In lorem. Donec elementum, lorem ut aliquam iaculis, lacus pede sagittis augue, eu tempor erat neque non quam. Pellentesque habitant morbi tristique', NULL, '2021-07-05 21:58:57', NULL),
(86, 'Dawn Colt', 'magnis@Duiscursusdiam.com', 17, 2, 1, 'interdum. Sed auctor odio a purus. Duis elementum, dui quis accumsan convallis, ante lectus convallis est, vitae sodales nisi magna sed dui.', NULL, '2021-07-05 21:58:57', NULL),
(87, 'Lareina Roth', 'Nulla.interdum@ante.org', 20, 5, 1, 'fringilla mi lacinia mattis. Integer eu lacus. Quisque imperdiet, erat nonummy ultricies ornare, elit elit fermentum risus, at fringilla purus mauris a', NULL, '2021-07-05 21:58:57', NULL),
(88, 'Vernon Stone', 'Sed.auctor.odio@in.net', 3, 2, 2, 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi a', NULL, '2021-07-05 21:58:57', NULL),
(89, 'Brandon Rina', 'Nulla.facilisi.Sed@adipiscing.ca', 15, 4, 5, 'sed pede nec ante blandit viverra. Donec tempus, lorem fringilla ornare placerat, orci lacus vestibulum lorem, sit amet ultricies sem magna nec', NULL, '2021-07-05 21:58:57', NULL),
(90, 'Mechelle Lana', 'ultrices@pedeacurna.co.uk', 2, 4, 1, 'ultricies adipiscing, enim mi tempor lorem, eget mollis lectus pede et risus. Quisque libero lacus, varius et, euismod et, commodo at, libero.', NULL, '2021-07-05 21:58:57', NULL),
(92, 'Karleigh Wyatt', 'dictum.eu@neceuismod.org', 14, 4, 5, 'ut odio vel est tempor bibendum. Donec felis orci, adipiscing non, luctus sit amet, faucibus ut, nulla. Cras eu tellus eu augue', NULL, '2021-07-05 21:58:57', NULL),
(93, 'Kameko Kirby', 'quam@enimconsequatpurus.com', 4, 3, 4, 'Cras dolor dolor, tempus non, lacinia at, iaculis quis, pede. Praesent eu dui. Cum sociis natoque penatibus et magnis dis parturient montes,', NULL, '2021-07-05 21:58:57', NULL),
(94, 'Orlando Tobias', 'felis.eget@lacusAliquamrutrum.edu', 17, 3, 5, 'Nunc lectus pede, ultrices a, auctor non, feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis eget, ipsum. Donec sollicitudin', NULL, '2021-07-05 21:58:57', NULL),
(95, 'Joel Fulton', 'tempor.diam@fringillaeuismod.org', 14, 1, 5, 'nec orci. Donec nibh. Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec enim. Nunc ut erat. Sed', NULL, '2021-07-05 21:58:57', NULL),
(96, 'Jack Armando', 'Sed.nunc.est@tempordiam.net', 4, 5, 2, 'ut, nulla. Cras eu tellus eu augue porttitor interdum. Sed auctor odio a purus. Duis elementum, dui quis accumsan convallis, ante lectus', NULL, '2021-07-05 21:58:57', NULL),
(97, 'Damian Fay', 'ipsum@Nam.org', 1, 3, 3, 'euismod in, dolor. Fusce feugiat. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam auctor, velit eget laoreet posuere, enim nisl elementum', NULL, '2021-07-05 21:58:57', NULL),
(98, 'Cora Keefe', 'feugiat.placerat.velit@tortorInteger.edu', 21, 5, 1, 'ultricies sem magna nec quam. Curabitur vel lectus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec dignissim', NULL, '2021-07-05 21:58:57', NULL),
(99, 'Caldwell Odessa', 'massa@Proinnonmassa.co.uk', 10, 4, 4, 'nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae mauris sit amet lorem', NULL, '2021-07-05 21:58:57', NULL),
(100, 'Giselle Bryar', 'blandit.viverra@Donecfelis.net', 20, 4, 5, 'dolor dapibus gravida. Aliquam tincidunt, nunc ac mattis ornare, lectus ante dictum mi, ac mattis velit justo nec ante. Maecenas mi felis,', NULL, '2021-07-05 21:58:57', NULL),
(115, 'Fajri', 'fajrisyifa@gmail.com', 21, 2, 5, 'cocok untuk nugas kampuss, wifinya kenceng minumannya juga enak-enak', NULL, '2021-07-05 21:58:57', NULL),
(116, 'aulia', 'aulia@gmail.com', 1, 2, 3, ';ebih khusyu ibadahnnya karena tempatnnya nyaman ', NULL, '2022-01-19 18:18:07', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(60) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `profesi_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama`, `username`, `email`, `password`, `role`, `profesi_id`, `created_at`, `last_login`, `foto`) VALUES
(1, 'Admin', 'Admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', 7, '2021-07-05 21:59:47', '2022-07-06 11:54:30', '56cc13e1256ebc7774e41ad94c6c7a50.jpg'),
(2, 'Nabila Fajri Syifa Dewi', 'bia10', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', 3, '2021-07-05 21:59:47', '2022-06-03 12:39:50', '16d33eef41b9d5a32459e322ae83d1ab.png'),
(12, 'Siti Rohmah', 'Rohmah02', 'member@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'member', 2, '2022-07-05 16:02:07', NULL, NULL),
(13, 'Nia Anggraeni', 'nia04', 'member@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'member', 7, '2022-07-05 16:04:10', NULL, NULL),
(14, 'Syavira Aulia Syamsi', 'syavira01', 'member@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'member', 3, '2022-07-05 16:05:39', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `wisata`
--

CREATE TABLE `wisata` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `jenis_wisata_id` int(11) DEFAULT NULL,
  `fasilitas` text DEFAULT NULL,
  `bintang` smallint(6) DEFAULT NULL,
  `kontak` varchar(45) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `latlong` varchar(50) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `web` varchar(45) DEFAULT NULL,
  `jenis_kuliner_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `wisata`
--

INSERT INTO `wisata` (`id`, `nama`, `deskripsi`, `jenis_wisata_id`, `fasilitas`, `bintang`, `kontak`, `alamat`, `latlong`, `email`, `web`, `jenis_kuliner_id`) VALUES
(1, 'Masjid Dian Al-Mahri', 'Di kota Depok juga tersedia wisata religi. Salah satunya ada di kawasan Meruyung yaitu Masjid Dian Al-Mahri.\r\n\r\nMenjadi yang resmi berdiri tanggal 31 Desember 2006 ini memiliki gaya arsitektur dan juga ornamen yang cantik. Kubahnya berwarna emas dengan dilengkapi lampu gantung hasil impor dari Italia yang sangat indah.\r\n\r\nBerkat keindahannya ini, Masjid Dian Al-Mahri dinobatkan sebagai satu dari sekian masjid paling megah dan paling cantik di Asia Tenggara.', 3, 'Masjid', 3, '-', 'pos security kubah emas, Jl. Meruyung Raya, Meruyung, Kec. Limo, kota, Jawa Barat 16515', '-6.550237, 106.806951', 'MasjidDianAl-Mahri@gmail.com', 'https://MasjidDianAl-Mahri.com', NULL),
(2, 'D’Kandang Amazing Farm', 'Menjadi salah satu tempat wisata edukasi, D’Kandang Amazing Farm sangat cocok untuk wisata bersama keluarga. Konsep wisatanya cukup unik. Pengunjung akan diajak berinteraksi langsung dengan hewan-hewan yang ada di sana dan juga berlatih bercocok tanam. Tak hanya itu, tempat wisata ini juga menyediakan aktivitas lain yang dapat menambah pengetahuan seputar kehidupan tradisional.', 2, 'Taman Bermain', 4, '02177887138', 'Jl. Penarikan No.RT 01 / 02, Pasir Putih, Kec. Sawangan, Kota Depok, Jawa Barat 16519', '-6.39, 106.83', 'DKandangAmazingFarm@gmail.com', 'https://test.com', NULL),
(3, 'Objek Wisata Godong Ijo', 'Saat berlibur, jangan lupa untuk berkunjung ke Godong Ijo. Di tempat ini, Anda dapat melakukan banyak aktivitas, seperti outbound, memancing ikan, bermain membatik, permainan tradisional, dan lain-lain.\r\nSuasana alamnya yang indah juga sangat cocok jika Anda hanya sekedar ingin bersantai bersama teman atau keluarga. Menariknya, tempat wisata ini juga menghadirkan Botanical Cafe yang khas dengan olahan singkongnya yang berasal dari Thailand.', 1, 'Taman', 3, '08122906800', 'Jl. Raya Cinangka Raya No.KM 10 No. 60, Serua, Kec. Bojongsari, Kota Depok, Jawa Barat 16517', '-6.3678288, 106.7456809', 'ObjekWisataGodongIjo@gmail.com', 'https://ObjekWisataGodongIj.com', NULL),
(4, 'Taman Wiladatika', 'Memiliki luas sekitar 15 hektar menjadikan tempat wisata ini sangatlah luas dan cantik. Banyak pengunjung mendatangi tempat ini karena pemandangannya yang indah dan udaranya yang sejuk disertai pohon-pohon rindang.\r\n\r\nTaman ini merupakan salah satu tempat wisata yang sudah ada sejak lama. Namun meski begitu, dengan desain yang cantik membuat tempat ini masih eksis sampai sekarang, baik untuk spot foto maupun hanya sekedar untuk jalan-jalan.', 2, 'Taman Bermain', 2, ' (021) 8731859', '3JJ5+WQV, Jalan, Braga, Sumurbandung, Bandung City, West Java', '-6.405518, 106.822802', 'TamanWiladatika@gmail.com', 'https://TamanWiladatika.com', NULL),
(5, 'Arina Waterpark', 'Sedikit berbeda dari waterpark pada umumnya, Arina Waterpark hadir di tengah-tengah perumahan. Ini yang menjadikan tempat ini unik dan pastinya memberikan sensasi kesegaran tersendiri.\r\n\r\nPerihal fasilitas, tak perlu khawatir. Fasilitas Arina Waterpark ini terbilang lengkap dan Anda bisa menikmati setiap kegiatannya dengan nyaman. Pemandangan di sekitar tempat ini pun asri dengan banyaknya pepohonan di dekat kolam renang.', 5, 'Kolom renang ', 3, '-', 'JPMC+QRH, Pd. Petir, Kec. Bojongsari, Kota Depok, Jawa Barat 16517', '-6.3655639, 106.7221161', 'ArinaWaterpark@gmail.com', 'https://ArinaWaterpark.com', NULL),
(6, 'Taman Rekreasi Pasir Putih', 'Tebing Keraton adalah sebuah tebing dengan pemandangan luar biasa di area Taman Hutan Raya Ir. H. Djuanda. Kalau ingin merasakan pengalaman melihat lautan pohon yang hijau dari atas tebing, di sinilah tempatnya.\r\nBanyak orang juga yang datang sekitar subuh untuk melihat matahari terbit di sini.', 5, 'Taman Bermain', 5, '02129434479', 'Jl. Garuda Raya No.1, RT.1/RW.7, Pasir Putih, Kec. Sawangan, Kota Depok, Jawa Barat 16519', '-6.4183499, 106.779947', 'TamanRekreasiPasirPutih@gmail.com', 'https://TamanRekreasiPasirPutih.com', NULL),
(7, 'Cagar Alam Depok', 'Sejak masa penjajahan Belanda, Cagar Alam Depok ini sudah ada. Usianya bahkan lebih tua dari Kebun Raya Bogor. Meski begitu, tempatnya masih terawat dan berfungsi sampai saat ini.\r\n\r\nMemiliki nama lain Cagar Alam Pancoran, objek wisata ini masihlah menjadi “rumah” bagi berbagai jenis satwa. Mulai dari musang, menjangan, berbagai jenis burung dan ular, serta masih banyak lagi.\r\nIni menjadi tempat yang cocok untuk mengajak anak-anak mengenal berbagai jenis satwa.', 2, 'Umum', 5, '-', 'HRR7+WJW, Pancoran MAS, Kec. Pancoran Mas, Kota Depok, Jawa Barat 16436', '-6.40652, 106.80069', 'CagarAlamDepok@gmail.com', 'https://CagarAlamDepok.com', NULL),
(8, 'Gema Pesona Depok', 'Sesuai namanya Taman Hutan Raya Ir. H. Djuanda,  memang bukan sekadar taman - ini adalah hutan kota yang terletak di area Dago Pakar. Taman yang kerap disebut Tahura oleh warga Bandung ini juga jadi salah satu tempat wisata di Bandung favorit - termasuk bagi masyarakat kota Bandung sekalipun.', 2, 'Umum', 2, '-', 'Desa Sukmajaya, Sukmajaya, Depok', '-6.40660641501, 106.838222865', 'GemaPesonaDepok@gmail.com', 'https://GemaPesonaDepok.com', NULL),
(9, 'Kampung 99 Pepohonan', 'Tempat yang satu ini cukup unik. Di Chinatown Bandung, anda bisa menemukan suasana zaman dulu di Bandung disini.', 2, 'Taman Bermain', 3, '-', 'Jl. KH. Muhasan 2, Meruyung, Kec. Limo, Kota Depok, Jawa Barat 16515', '-6.389069, 106.82927', 'Kampung99Pepohonan@gmail.com', 'https://Kampung99Pepohonan.com', NULL),
(10, 'Wisata Air Situ Cilodong', 'Jika ingin berlibur dengan keluarga, mungkin Situ Cilodong bisa menjadi pilihan yang tepat. Dengan dilengkapi area pemancingan, Anda bisa bersantai dengan keluarga sambil menikmati pemandangan sekitar yang memukau\r\n\r\nTerdapat juga wahana baru bernama balon air yang cocok Anda jajal bersama keluarga. Jika lapar, ada warung yang bisa Anda kunjungi. Jadi, Anda tak perlu repot-repot membawa perbekalan yang banyak.', 2, 'umum', 3, '-', 'Kalibaru, Kec. Cilodong, Kota Depok, Jawa Barat', '-6.39, 106.83', 'SituCilodong@gmail.com', 'https://SituCilodong.com', NULL),
(11, 'Pondok Zidane', 'Pondok Zidane bisa Anda jadikan sebagai alternatif jika Anda ingin berlibur bersama anak-anak. Tempat wisata Depok untuk anak ini sering menjadi tujuan study tour bagi anak SMP dan SD.\r\n\r\nAda berbagai kegiatan menarik yang dapat dilakukan anak-anak. Mulai dari outbound hingga bermain di waterpark. Di sana anak-anak juga bisa berlatih untuk bercocok tanam secara hidroponik.', 2, 'Taman Bermain', 5, '081314631400', 'Jalan Kekupu Blok, Blok Porek 1, Bedahan, Kec. Sawangan, Kota Depok, Jawa Barat 16519', '-6.43310613541, 106.776280342', 'PondokZidane@gmail.com', 'https://PondokZidane.com', NULL),
(12, 'Walking Drums', 'Walking Drums cabang Depok ini sungguh asyik untuk tempat bertemu teman lama atau sekadar bergosip bersama sahabat karibmu. Di siang hari, langit yang cerah akan membuatmu merasa hangat. Di malam hari, penerangan yang kekinian akan membuat spot pilihanmu kelihatan makin keren. Menu-menunya juga akan membuat perutmu keroncongan. Tongseng kambing, nasi gurih ayam ungkep atau gnocchi gorgonzola akan memuaskan semua keinginanmu. Minuman kopi kacang ijo atau dates smoothies ditemani dengan aneka varian cake bisa jadi alasan untuk melupakan dietmu sejenak.', NULL, 'cafe', 3, '-', 'Jl. Margonda Raya No.426, Pondok Cina, Kecamatan Beji, Depok', '-6.36730825871, 106.834273338', 'WalkingDrums@gmail.com', 'https://WalkingDrums.com', 1),
(13, 'Mill Point Cafe, Depok', 'Mill Point Cafe ini bakal benar-benar menghibur matamu saat di Depok. Dari penampakan luarnya yang terkesan tua namun nyeni saja sudah membuat penasaran. Masuk ke dalamnya, interior kafe ini terasa segar dengan warna-warna yang atraktif.\r\nPizza dan salmon kani mentai yang diberi topping berlimpah ini bisa kamu temukan. Tidak puas dengan ini, kamu juga bisa memesan steak tempe spesial dan pisang fantasi yang bisa kamu bayangkan enaknya.', NULL, 'cafe', 2, '-', 'Jl. Raya KSU No.9, RT.4/RW.1, Tirtajaya, Kec. Sukmajaya, Depok', '-6.40807775758, 106.833659304', 'MillPointCafeDepok@gmail.com', 'https://MillPointCafeDepok.com', 1),
(14, 'di Kode-In Coffee and Eatery', 'Kode-In Coffee and Eatery menampilkan gaya di dalam dan luar ruangan yang punya atmosfer berbeda. Kalau mau mendapatkan suasana yang teduh, coba saja duduk di dalam ruangannya yang didominasi warna coklat. Tapi kalau kamu ingin merasakan nuansa liburan yang meriah, pilih area dengan bean bag berwarna cerah dan alas rumput ini.\r\nMenu-menu dari yang manis sampai gurih bisa kamu cicipi. Misalnya waffle special KODEin,  geprek KODEin dan minuman kopi susu pisang. Kombinasi hidangan lokal dan mancanegara ini akan membuat waktu santaimu berlalu tanpa terasa.', NULL, 'View', 5, '-', 'Jl. Gema Insani, Bakti Jaya, Kec. Sukmajaya, Depok', '-6.3807327, 106.8514399', 'diKode-InCoffeeandEatery@gmail.com', 'https://diKodeInCoffeeandEatery.com', 1),
(15, 'LOUIS', 'LOUIS menjadi alternatif bagi kamu yang menyukai nuansa antik. Penataan luar ruang di depan bangunan bergaya kolonial, ditambah lagi menggunakan perabot kayu yang unik akan menghasilkan pengalaman berkuliner yang tidak ada duanya. Bila kamu datang di sore hari, penerangan di sini akan membuat suasana terasa romantis.\r\nCicipi menu spaghetti aglio olio yang dipasangkan dengan segelas latte nan instagenik ini. Banyak juga menu lokal yang sama menggugahnya seperti kue balalapis, asinan betawi hingga keripik singkong caramel yang bakal membuatmu makin betah mengobrol.', NULL, 'Restaurant', 3, '-', 'Jl. Mawar No.22, Depok, Kec. Pancoran Mas, Depok', '-6.40065347, 106.82467555', 'LOUIS@gmail.com', 'https://LOUIS.com', 2),
(16, 'Milan Pizzeria Cafe Depok', 'Milan Pizzeria Cafe juga jadi sebuah lokasi hits untuk kopi darat di Depok. Tumbuhan artifisial dan perabotan kayu dengan warna-warni serasi membuat kafe terasa chic dan nyaman. Tidak ketinggalan bangku berupa ayunan dengan tembok yang menarik untuk diabadikan ini.\r\nNamanya pizzeria tapi kamu tetap dapat menemukan hidangan khas Nusantara semisal nasi ayam lada hitam. Tetapi tentu saja yang menonjol di kafe ini adalah hidangan pizza dan pasta yang banyak ragamnya. Smoke spicy fettucine, mashed potato cheezy beef hingga banana pizza dengan keju dan kayu manis sangat menggoda untuk dicoba.', NULL, 'Cafe', 1, '-', 'Jl. Margonda Raya No.514, Pondok Cina, Kecamatan Beji, Depok', '-6.360268, 106.833167', 'MilanPizzeriaCafeDepok@gmail.com', 'https://MilanPizzeriaCafeDepok.com', 1),
(17, 'The Manor Cafe Depok', 'The Manor Cafe ini berlokasi di The Manor Andara yang mewah dan dapat disewa untuk acara-acara khusus. Meski mungil, namun The Manor Cafe sangat mengesankan berkat dekorasinya yang mengingatkan pada kafe-kafe di Paris. Kamu juga bisa makan dengan nuansa piknik di luar ruangan lho!\r\nUntuk melengkapi suasana yang ada, kamu bisa mencicipi berbagai pastry yang dilengkapi dengan ice coffee manor. Dilengkapi dengan penataan yang cantik, pengalaman “piknik” di The Manor Cafe akan sulit untuk dilupakan.', NULL, 'Tempat Ternyaman', 3, '-', 'Jl. Ibnu Armah No.8, Pangkalan Jati, Kec. Cinere, Depok', '-6.32874, 106.7987', 'PiknikalaistanadiTheMano@gmail.com', 'https://PiknikalaistanadiTheMano.com', 1),
(18, 'di Beranda Depok Cafe & Resto', 'Duduk sambil menatap hamparan pepohonan di Beranda Depok Cafe & Resto,Beranda Depok Cafe & Resto memiliki area yang kece untuk dinikmati. Suka dengan dinding yang diramaikan mural? Atau ingin makan kenyang sambil cuci mata melihat alam yang asri? Semua ada di sini! \r\nMenu seperti nasi jinggo dan soto betawi tersedia bagi kamu yang ingin makan nasi dan lauknya. Sedangkan kalau mau yang sedikit berbeda, kamu juga bisa memesan chicken maryland atau sirloin steak. Suka-suka kamu deh!', NULL, 'view', 3, '-', 'Jl. Kartini L No.11K, Depok, Kec. Pancoran Mas, Depok', ' -6.385589, 106.830711.', 'diBerandaDepokCafeResto@gmail.caom', 'https://diBerandaDepokCafeResto.com', 1),
(19, 'Tamelo Atap Cafe', 'Namanya memang pas dengan lokasi kafenya. Tamelo Atap Cafe memungkinkan kamu merasakan hangatnya matahari hingga semilir angin sore yang nikmat. Di mana lagi kamu bisa melihat kota Depok dari ketinggian seperti ini?\r\nChicken baked rice dan minuman pink lady dapat menambah seru acara nongkrong atau kencanmu di sini. Tentunya hidangan kamu santap akan terasa semakin enak berkat pemandangan keren di sekelilingmu.', NULL, 'Cafe', 3, '-', ' Rooftop Lt.25 Apartemen Taman Melati Margonda 2 Tower C, Jl. Margonda Raya No.525A, Pondok Cina, Kecamatan Beji, Depok', ' -6.385589, 106.830711.', 'TameloAtapCafe@gmail.com', 'https://TameloAtapCafe.com', 1),
(20, 'Jacob Koffie Huis', 'Jacob Koffie Huis ini jadi kafe favorit karena siapa yang tidak akan suka disuguhi pemandangan cantik seperti ini? Meski di dalam ruang, namun dengan penataan sedemikian rupa dengan dominasi warna putih, semua akan setuju jika kafe ini artistik dan asyik untuk tempat nongkrong.\r\nChicken caesar salad diikuti grilled chicken mustard akan jadi menu sempurna untuk makan siangmu. Red velvet ice cream dan segelas americano menjadi pelengkap yang memberi rasa pahit dan manis yang nikmat.', NULL, 'Restaurant', 3, '-', 'Jl. Kemuning No.1, Depok, Kec. Pancoran Mas, Depok', '-6.4000468914, 106.819531918', 'JacobKoffieHuis@gmail.com', 'https://JacobKoffieHuis.com', 2),
(21, 'Kopium Artisan Coffee', 'Kopium Artisan Coffee menawarkan suasana bervariasi yang bisa kamu pilih sesuai mood. Mau duduk tenang sendirian saja, maka ruangan dengan warna monokrom ini pasti sesuai untukmu. Atau sedang merasa gembira dan penuh semangat? Maka latar yang cerah dan unik ini dapat menambah keceriaanmu.\r\nKudapan santai seperti nachos ditemani sebotol kopi cold brew dapat membuatmu segar kembali. Kalau setelahnya malah jadi lapar mata, kamu bisa memesan menu berat seperti kampoeng fried rice atau chicken blackpepper rice.', NULL, 'Restaurant', 3, '-', 'Jalan Margonda, 2 No.498 D, RW.004, Pondok Cina, Kecamatan Beji, Depok', ' -6.385589, 106.830711.', 'KopiumArtisanCoffee@gmail.com', 'https://KopiumArtisanCoffee.com', 2),
(22, 'JPW Cafe & Garden', '-', NULL, 'Cafe', 3, '081281999168', 'Ruko Verbena D-16, Jl. Boulevard Grand Depok City, Tirtajaya, Kec. Sukmajaya, Kota Depok, Jawa Barat 16412', '-6.4134383, 106.821045', 'JPWCafe&Garden@gmail.com', 'https://JPWCafeGarden.com', 1),
(31, 'ARTiVATOR', 'ARTiVATOR ini adalah cafe sekaligus galeri seni di Depok, sehingga kamu yang mengaku pencinta seni, wajib datang ke sini. Pasti panasnya matahari Depok langsung tidak terasa begitu kamu masuk ke dalam kafe yang artistik dan terkesan adem ini. Menu-menu yang membuat perut nyaman akan menyambutmu, sebut saja fish cake indomie, nasi ayam hainan atau nasi kecombrang ARTiVATOR. Minuman sehat semacam jus nanas madu hingga lemon mojito akan bikin kerongkonganmu terasa bersih dan segar kembali.', NULL, 'Cafe', 0, '-', ' Jl. Pemuda No.86, Depok, Kec. Pancoran Mas, Depok', '-6.40156184867, 106.826586874', 'ARTiVATOR@gmail.com', 'https://ARTiVATOR.com', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `gallery_wisata`
--
ALTER TABLE `gallery_wisata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_GALLERY_FOTO REF_WISATA` (`wisata_id`);

--
-- Indeks untuk tabel `jenis_kuliner`
--
ALTER TABLE `jenis_kuliner`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jenis_wisata`
--
ALTER TABLE `jenis_wisata`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `profesi`
--
ALTER TABLE `profesi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_testimoni_profesi1` (`profesi_id`),
  ADD KEY `fk_testimoni_wisata1` (`wisata_id`),
  ADD KEY `fk_testimoni_user_id` (`user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_PROFESI_ID_REF_PROFESI` (`profesi_id`);

--
-- Indeks untuk tabel `wisata`
--
ALTER TABLE `wisata`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_wisata_jenis_wisata_idx` (`jenis_wisata_id`),
  ADD KEY `fk_wisata_jenis_kuliner1_idx` (`jenis_kuliner_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `gallery_wisata`
--
ALTER TABLE `gallery_wisata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT untuk tabel `jenis_kuliner`
--
ALTER TABLE `jenis_kuliner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `jenis_wisata`
--
ALTER TABLE `jenis_wisata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `profesi`
--
ALTER TABLE `profesi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `wisata`
--
ALTER TABLE `wisata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `gallery_wisata`
--
ALTER TABLE `gallery_wisata`
  ADD CONSTRAINT `FK_GALLERY_FOTO REF_WISATA` FOREIGN KEY (`wisata_id`) REFERENCES `wisata` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `testimoni`
--
ALTER TABLE `testimoni`
  ADD CONSTRAINT `fk_testimoni_profesi1` FOREIGN KEY (`profesi_id`) REFERENCES `profesi` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_testimoni_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_testimoni_wisata1` FOREIGN KEY (`wisata_id`) REFERENCES `wisata` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_PROFESI_ID_REF_PROFESI` FOREIGN KEY (`profesi_id`) REFERENCES `profesi` (`id`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `wisata`
--
ALTER TABLE `wisata`
  ADD CONSTRAINT `fk_wisata_jenis_kuliner1` FOREIGN KEY (`jenis_kuliner_id`) REFERENCES `jenis_kuliner` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_wisata_jenis_wisata` FOREIGN KEY (`jenis_wisata_id`) REFERENCES `jenis_wisata` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
