<div class="carousel slide" id="carousel-711235">
    <ol class="carousel-indicators">
        <li data-slide-to="0" data-target="#carousel-711235" class="active">
        </li>
        <li data-slide-to="1" data-target="#carousel-711235">
        </li>
        <li data-slide-to="2" data-target="#carousel-711235">
        </li>
    </ol>
    <div class="carousel-inner" style="margin-top: 3.5rem!important;margin-bottom: -3rem!important;">
        <div class="carousel-item active">
            <img class="d-block w-100" alt="Carousel Bootstrap First" src="<?php echo base_url(); ?>assets/dist/img/slide/a.jpg" />
            <div class="carousel-caption">
                <h4>
                    Wisata Rekreasi & Kuliner Unggulan Kota Depok
                </h4>
                <p>
                    Nikmatin berbagai pilihan Wisata Rekreasi & Wisata Kuliner yang terbaik di Kota Depok
                </p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" alt="Carousel Bootstrap Second" src="<?php echo base_url(); ?>assets/dist/img/slide/b.jpg" />
            <div class="carousel-caption">
                <h4>
                    Daftar Wisata Di Depok
                </h4>
                <p>
                    Di Kota Depok anda akan menemukan berbagai Wisata Rekreasi yang terbaik baik untuk anda maupun untuk
                    keluarga anda.
                </p>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" alt="Carousel Bootstrap Third" src="<?php echo base_url(); ?>assets/dist/img/slide/c.jpg" />
            <div class="carousel-caption">
                <h4>
                    Daftar Wisata Kuliner Di Depok
                </h4>
                <p>
                    Makanan terbaik kuliner di Kota Depok kami sajikan berbagai macam pilihan ketika anda berkunjung di Kota
                    Depok
                </p>
            </div>
        </div>
    </div> <a class="carousel-control-prev" href="#carousel-711235" data-slide="prev"><span class="carousel-control-prev-icon"></span> <span class="sr-only">Previous</span></a> <a class="carousel-control-next" href="#carousel-711235" data-slide="next"><span class="carousel-control-next-icon"></span> <span class="sr-only">Next</span></a>
</div>