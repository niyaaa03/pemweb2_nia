<?php
$id = $this->session->userdata('id');
$userLogin = $this->user_model->findById($id);
$userProfesi = $this->profesi_model->findById($userLogin->profesi_id);
$fotoPath = 'assets/upload/user/' . $userLogin->foto;
$foto = (file_exists($fotoPath)) ? $fotoPath : 'assets/dist/img/default.png';
$this->load->view('function/function');
$uriString = $this->uri->uri_string();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Wisata Depok | Sistem Informasi Wisata Kota Depok</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/dist/img/logo-depok.png">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/toastr/toastr.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/dist/css/style.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed text-sm">
  <div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-dark navbar-blue text-sm border-bottom-0">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
          <a href="#" class="nav-link">
            Sistem Informasi Wisata Kota Depok
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="dropdown user user-menu">
          <a class="nav-link" data-toggle="dropdown" href="#">
            <img src="<?= base_url().$foto; ?>" class="user-image-sm" alt="User Image">
            <span class="hidden-xs"><?= $userLogin->username; ?></span>
          </a>
          <ul class="dropdown-menu">
            <li class="user-header">
              <img src="<?= base_url().$foto; ?>" class="img-circle" alt="User Image">
              <p>
                <?= $userLogin->username;  ?> - <?= $this->session->userdata('profesi') ?>
                <small>Member since - <?php echo date("d F Y", strtotime($userLogin->created_at));  ?></small>
              </p>
            </li>
            <!-- Menu Footer-->
            <li class="user-footer">
              <div class="float-left">
                <a href="<?php echo base_url(); ?>profile" class="btn btn-primary btn-sm">Profile</a>
              </div>
              <div class="float-right">
                <a href="<?php echo base_url(); ?>login/logout" class="btn btn-danger btn-sm">Log out</a>
              </div>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-widget="fullscreen" href="#" role="button">
            <i class="fas fa-expand-arrows-alt"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
            <i class="fas fa-th-large"></i>
          </a>
        </li>
      </ul>
    </nav>
    <aside class="main-sidebar main-sidebar-custom sidebar-light-primary elevation-4">
      <a href="<?php echo base_url(); ?>" class="brand-link text-sm navbar-blue">
        <img src="<?php echo base_url(); ?>assets/dist/img/logo-depok.png" alt="AdminLTE Logo" class="brand-image elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light text-light">Wisata Depok</span>
      </a>

      <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
          <div class="image">
            <img src="<?= base_url().$foto; ?>" class="img-circle elevation-2" alt="User Image">
          </div>
          <div class="info">
            <a href="<?php echo base_url(); ?>admin/home" class="d-block">Admin</a>
          </div>
        </div>

        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column nav-flat nav-compact nav-child-indent" data-widget="treeview" role="menu" data-accordion="false">
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/home" class="nav-link <?= checkUri($uriString, 'home') ?>">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                  Dashboard
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/testimoni" class="nav-link <?= checkUri($uriString, 'testimoni') ?>">
                <i class="nav-icon fas fa-comment"></i>
                <p>
                  Testimony Wisata Kota Depok
                </p>
              </a>
            </li>
            <li class="nav-item <?php if (strpos($uriString, 'wisata/')) {
                                  echo "menu-open";
                                } ?>">
              <a href="#" class="nav-link <?= checkUri($uriString, 'wisata/') ?>">
                <i class="nav-icon fas fa-copy"></i>
                <p>
                  Wisata Kota Depok
                  <i class="fas fa-angle-left right"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?php echo base_url(); ?>admin/wisata/rekreasi" class="nav-link <?= checkUri($uriString, 'rekreasi') ?>">
                    <i class="far fa-circle nav-icon text-info"></i>
                    <p>Wisata Rekreasi Kota Depok</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo base_url(); ?>admin/wisata/wisata_kuliner" class="nav-link <?= checkUri($uriString, 'wisata_kuliner') ?>">
                    <i class="far fa-circle nav-icon text-info"></i>
                    <p class="">Wisata Kuliner Kota Depok</p>
                  </a>
                </li>
              </ul>
            </li>
            <li class="nav-header">Data Rekreasi dan Kuliner Kota Depok</li>

            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/jenis_wisata" class="nav-link <?= checkUri($uriString, 'jenis_wisata') ?>">
                <i class="nav-icon fas fa-map-marked-alt"></i>
                <p>
                  Jenis-Jenis Rekreasi
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/jenis_kuliner" class="nav-link <?= checkUri($uriString, 'jenis_kuliner') ?>">
                <i class="nav-icon fas fa-drumstick-bite"></i>
                <p>
                  Jenis-Jenis Kuliner
                </p>
              </a>
            </li>

            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/profesi" class="nav-link <?= checkUri($uriString, 'profesi') ?>">
                <i class="nav-icon fas fa-industry"></i>
                <p>
                  Profesi user
                </p>
              </a>
            </li>

            <li class="nav-header">Profile</li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>admin/users" class="nav-link <?= checkUri($uriString, 'users') ?>">
                <i class="nav-icon fas fa-users"></i>
                <p>
                  User Admin
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>profile" class="nav-link <?= checkUri($uriString, 'profile') ?>">
                <i class="nav-icon fas fa-user"></i>
                <p>
                  Profile
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo base_url(); ?>about" class="nav-link <?= checkUri($uriString, 'about') ?>">
                <i class="nav-icon fas fa-info-circle"></i>
                <p>
                  About
                </p>
              </a>
            </li>
          </ul>
        </nav>
      </div>
    </aside>