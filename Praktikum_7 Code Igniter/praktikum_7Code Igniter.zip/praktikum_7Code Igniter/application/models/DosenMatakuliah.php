<?php
class DosenMatakuliah_model extends CI_model {
    public $semester;
    public $dosen;
    public $matakuliah;
   
}

?>