<?php
class Matakuliah_model extends CI_model {
    public $nama;
    public $sks;
   
}

?>