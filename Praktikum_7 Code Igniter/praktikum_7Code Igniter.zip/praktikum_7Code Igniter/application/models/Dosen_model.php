<?php
class Dosen_model extends CI_model {
    public $nama;
    public $matakuliah;
    public $gender;
   

}

?>